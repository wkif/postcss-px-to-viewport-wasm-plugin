import * as wasm from "./postcss_px_to_viewport_wasm_plugin_bg.wasm";
import { __wbg_set_wasm } from "./postcss_px_to_viewport_wasm_plugin_bg.js";
__wbg_set_wasm(wasm);
export * from "./postcss_px_to_viewport_wasm_plugin_bg.js";

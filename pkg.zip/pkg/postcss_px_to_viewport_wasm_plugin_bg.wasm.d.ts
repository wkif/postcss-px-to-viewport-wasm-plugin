/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function __wbg_conversionoptions_free(a: number): void;
export function conversionoptions_new(a: number, b: number, c: number): number;
export function conversionoptions_prototype_width(a: number): number;
export function conversionoptions_ignore_case(a: number): number;
export function conversionoptions_conversion_precision(a: number): number;
export function convert_px_to_vw_with_options(a: number, b: number, c: number, d: number): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_malloc(a: number, b: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number, d: number): number;
export function __wbindgen_free(a: number, b: number, c: number): void;

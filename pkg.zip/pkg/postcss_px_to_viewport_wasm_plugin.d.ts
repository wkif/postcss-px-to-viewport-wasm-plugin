/* tslint:disable */
/* eslint-disable */
/**
* @param {string} html_str
* @param {ConversionOptions} options
* @returns {string}
*/
export function convert_px_to_vw_with_options(html_str: string, options: ConversionOptions): string;
/**
*/
export class ConversionOptions {
  free(): void;
/**
* @param {number} prototype_width
* @param {boolean} ignore_case
* @param {number} conversion_precision
*/
  constructor(prototype_width: number, ignore_case: boolean, conversion_precision: number);
/**
* @returns {number}
*/
  prototype_width(): number;
/**
* @returns {boolean}
*/
  ignore_case(): boolean;
/**
* @returns {number}
*/
  conversion_precision(): number;
}
